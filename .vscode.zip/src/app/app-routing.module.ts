import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GoalSettingComponent } from './goal-setting/goal-setting.component';
const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([{
    path:'goal',component:GoalSettingComponent
  }])

  ],
           
  exports: [RouterModule]
})
export class AppRoutingModule { }
